# AI prompt log and mentor response

- Prompt: Compare CSS Grid and Flexbox for a two-column asymmetric photo mosaic and a one-dimensional author metadata row.
- Prompt: Explain Bootstrap breakpoints col-12, col-md-6, col-lg-3 and spacing utilities such as gap-3.
- Applied: Grid areas for the mosaic, Flexbox for author alignment, Bootstrap card and responsive columns for recommendations.
- Mentor response (gộp một lần): Flexbox gọn hơn Bootstrap row/col cho author row một chiều vì align-items căn avatar, tên và nút chia sẻ trực tiếp mà không cần thêm cột. Float làm nội dung trôi quanh phần tử và có thể khiến cha không ôm chiều cao con; Flexbox giữ phần tử trong luồng. Grid tự tạo hàng cho ảnh bổ sung theo quy tắc lưới; có thể dùng auto-rows và breakpoint để điều khiển. Dùng gap để khoảng cách đều thay margin rời rạc.
