# Activity 473 — English–Vietnamese dictionary

Jakarta Servlet 6 Maven WAR for Tomcat 10.1+. Search the included basic vocabulary (hello, book, computer, apple, cat, water, friend, school); unknown terms show the required not-found message. Build with `mvn clean package`; deploy `target/jsp-servlet-dictionary.war`. No server was started or deployed here.
