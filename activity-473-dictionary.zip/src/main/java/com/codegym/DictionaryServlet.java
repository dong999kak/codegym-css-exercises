package com.codegym;

import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DictionaryServlet", urlPatterns = "/translate")
public class DictionaryServlet extends HttpServlet {
    private static final Map<String, String> WORDS = Map.ofEntries(
            Map.entry("hello", "Xin chào"), Map.entry("book", "Quyển sách"),
            Map.entry("computer", "Máy tính"), Map.entry("apple", "Quả táo"),
            Map.entry("cat", "Con mèo"), Map.entry("water", "Nước"),
            Map.entry("friend", "Người bạn"), Map.entry("school", "Trường học"));

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String word = request.getParameter("word");
        if (word == null) word = "";
        word = word.trim();
        String meaning = WORDS.get(word.toLowerCase(java.util.Locale.ROOT));
        String result = meaning == null ? "Không tìm thấy từ: " + word : meaning;
        try (var out = response.getWriter()) {
            out.printf("<!doctype html><html lang=\"vi\"><head><meta charset=\"UTF-8\"><title>Kết quả tra từ</title></head>"
                    + "<body style=\"font:1.2rem system-ui;text-align:center;margin:14vh auto;background:#f5f3ff\">"
                    + "<h1>%s</h1><p>%s</p><a href=\"index.jsp\">Tra từ khác</a></body></html>",
                    escape(word), escape(result));
        }
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
