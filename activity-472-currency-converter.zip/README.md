# Activity 472 — USD to VND converter

Jakarta Servlet 6 Maven WAR for Tomcat 10.1+. Enter the exchange rate and USD amount; the POST Servlet multiplies them and formats the VND result. Build using `mvn clean package`, then deploy `target/jsp-servlet-currency-converter.war`. Deployment has not been performed here.
