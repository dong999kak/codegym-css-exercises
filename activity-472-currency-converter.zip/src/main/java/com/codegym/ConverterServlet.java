package com.codegym;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ConverterServlet", urlPatterns = "/convert")
public class ConverterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            BigDecimal rate = new BigDecimal(request.getParameter("rate"));
            BigDecimal usd = new BigDecimal(request.getParameter("usd"));
            if (rate.signum() <= 0 || usd.signum() < 0) throw new NumberFormatException();
            String vnd = rate.multiply(usd).setScale(0, RoundingMode.HALF_UP)
                    .toPlainString().replaceAll("\\B(?=(\\d{3})+(?!\\d))", ",");
            try (var out = response.getWriter()) {
                out.printf("<!doctype html><html lang=\"vi\"><meta charset=\"UTF-8\"><title>Kết quả</title>"
                        + "<body style=\"font:1.2rem system-ui;text-align:center;margin:12vh auto;background:#f1f5f9\">"
                        + "<h1>Kết quả chuyển đổi</h1><p>%s USD × %s = <strong>%s VNĐ</strong></p>"
                        + "<a href=\"index.jsp\">Chuyển đổi tiếp</a></body></html>", usd.toPlainString(), rate.toPlainString(), vnd);
            }
        } catch (RuntimeException ex) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Invalid rate or USD amount. <a href='index.jsp'>Try again</a>");
        }
    }
}
