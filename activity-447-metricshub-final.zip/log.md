# AI prompt log

- Prompt: Compare Flexbox and CSS Grid for a responsive dashboard with flexible navigation, asymmetric Bento widgets, and three pricing cards.
- Follow-up: Explain how gap replaces scattered margins and how flex-wrap helps a mobile navbar.
- Applied: Grid for the two-dimensional dashboard and widget spans; Flexbox for content-first navigation and item alignment; Bootstrap 12-column grid for pricing.
- Mentor response (gộp một lần): Có thể kết hợp Grid và Flexbox: dùng Flexbox căn giữa icon và chữ trong widget thuộc Grid. Bootstrap 4+ dùng Flexbox cho Grid để các cột co giãn theo breakpoint, có gutter và quy tắc nhất quán nhanh hơn tự viết. Với layout zig-zag hai chiều, chọn CSS Grid vì có thể đặt phần tử vào hàng/cột và span chính xác; Flexbox phù hợp hơn cho một trục. Dùng gap trên Grid/Flexbox để tạo khoảng cách đều mà không cần margin rời rạc.
