# Strategy

CSS Grid phù hợp với Dashboard vì đây là bố cục hai chiều: widget có thể trải qua nhiều hàng hoặc cột. Flexbox phù hợp với Navbar vì căn chỉnh một chiều và phân phối khoảng trống theo nội dung kể cả khi nhãn dài. Pricing dùng Bootstrap row và col-12 col-md-4 để tạo ba cột ở màn hình vừa trở lên và xếp chồng trên điện thoại. Grid và Flexbox kết hợp được: bên trong widget thuộc Grid, Flexbox căn giữa icon và chữ. Bootstrap Grid từ phiên bản 4 dựa trên Flexbox, cung cấp breakpoint và khoảng cách nhất quán. Grid phù hợp hơn với bố cục tổng thể phức tạp như Bento hoặc zig-zag.
