# AI prompt log

Prompt: Compare Flexbox and CSS Grid for a responsive dashboard with a flexible navigation bar, asymmetric Bento widgets, and three pricing cards.
Applied: Grid for the two-dimensional dashboard and widget spans; Flexbox for content-first navigation; Bootstrap 12-column grid for pricing.
Follow-up: Explain flex-wrap for the mobile navbar and why gap is preferable to scattered margins.
