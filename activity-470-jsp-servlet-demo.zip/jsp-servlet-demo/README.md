# Activity 470 — JSP/Servlet server time

Maven web application for Java 17 and Apache Tomcat 10.1+ (Jakarta Servlet 6). The JSP landing page links to a servlet at /hello; the servlet renders the current server time for each request.

Build from this directory with mvn clean package. Deploy target/jsp-servlet-demo.war to Tomcat's webapps directory. Open /jsp-servlet-demo/ and /jsp-servlet-demo/hello.

No server was started or deployed by this package.
