package com.codegym;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloServlet", urlPatterns = {"/hello"})
public class HelloServlet extends HttpServlet {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy · HH:mm:ss");
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String currentTime = LocalDateTime.now().format(FORMAT);
        try (var out = response.getWriter()) {
            out.println("<!doctype html><html lang=\"vi\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>Thời gian máy chủ</title></head>");
            out.println("<body style=\"font:16px system-ui;text-align:center;margin:10vh auto;max-width:700px;background:#f5f7fb;color:#1e293b\"><main style=\"padding:3rem;background:white;border-radius:1rem;box-shadow:0 8px 30px #1e293b18\">");
            out.println("<p style=\"color:#2563eb;text-transform:uppercase;letter-spacing:.15em\">CodeGym · Java Web</p><h1>Thời gian hiện tại trên máy chủ</h1>");
            out.println("<p style=\"font-size:1.5rem\">" + currentTime + "</p><p>Mỗi lần tải lại, Servlet tạo thời gian mới từ phía server.</p><a href=\"index.jsp\">← Trang chủ</a></main></body></html>");
        }
    }
}
